Documentation Version (1)
<?php

echo gethostname();

?>